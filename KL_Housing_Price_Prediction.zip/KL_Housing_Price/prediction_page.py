import numpy as np
import pickle
import streamlit as st
import base64

# Load the saved model with caching
@st.cache(allow_output_mutation=True)
def load_model():
    try:
        with open("house_price_prediction_model.sav", 'rb') as model_file:
            return pickle.load(model_file)
    except Exception as e:
        st.error(f"Error loading the model: {e}")
        return None

loaded_model = load_model()

# Function for prediction
def house_price_prediction(input_data):
    try:
        # Convert input data to numpy array
        input_data_as_numpy_array = np.asarray(input_data)

        # Reshape the array as we are predicting on 1 instance
        input_data_reshaped = input_data_as_numpy_array.reshape(1, -1)

        prediction = loaded_model.predict(input_data_reshaped)
        return prediction[0] * 1_000_000  # Multiply by 1,000,000
    except Exception as e:
        st.error(f"Error during prediction: {e}")
        return None

def get_img_as_base64(file):
    with open(file, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

def main():
    # Encode the local image to base64
    img_file_path = "image/blue_house.jpg"  # Path to your image in the image folder
    img_base64 = get_img_as_base64(img_file_path)

    # Define background image and additional styling
    page_bg_img = f"""
    <style>
        [data-testid="stAppViewContainer"] {{
            background-image: url("data:image/png;base64,{img_base64}");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }}

        [data-testid="stHeader"] {{
            background-color: rgba(0, 0, 0, 0);
        }}

        [data-testid="stSidebar"] {{
            background: rgba(255, 255, 255, 0.7);
        }}

        [data-testid="stSidebarNav"]::before {{
            content: "LuminaryHomesKL";
            font-size: 20px;
            color: #ffffff;
            margin-left: 20px;
            margin-top: 20px;
            display: block;
        }}

        [data-testid="stToolbar"] {{
            right: 2rem;
        }}
        
        .main-header {{
            font-size: 32px;
            font-weight: bold;
            color: #ffffff;
            text-align: center;
            margin-top: 20px;
            margin-bottom: 40px;  /* Added margin-bottom to create a gap */
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }}

        .main-content {{
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
            margin-top: 20px;
        }}

        .main-content p {{
            font-size: 18px;
            color: #333333;
            line-height: 1.6;
        }}

        .main-content h4 {{
            font-size: 24px;
            color: #333333;
            margin-top: 20px;
        }}

        .main-content ul {{
            font-size: 18px;
            color: #333333;
            line-height: 1.6;
            list-style-type: disc;
            margin-left: 20px;
        }}

        .main-content ul li {{
            margin-bottom: 10px;
        }}
        
        .stButton button {{
            background-color: #4CAF50;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 12px;
            border: none;
            transition: background-color 0.3s ease;
        }}

        .stButton button:hover {{
            background-color: #45a049;
        }}

        .predicted-price {{
            font-size: 24px;
            font-weight: bold;
            color: #ffffff;
            background-color: #4CAF50;
            padding: 10px;
            border-radius: 10px;
            text-align: center;
            margin-top: 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }}

        .stSelectbox, .stNumberInput {{
            margin-bottom: 20px;
        }}

        .bold-label {{
            font-weight: bold;
            font-size: 18px;
            color: #ffffff;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }}

        .input-container {{
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
            margin-top: 40px;  /* Increased margin-top to create a gap */
        }}
    </style>
    """

    # Apply background image style
    st.markdown(page_bg_img, unsafe_allow_html=True)

    # Prediction Page Content
    st.markdown("""
        <div class="main-header">
            House Price Prediction
        </div>

    """, unsafe_allow_html=True)

    # List of locations
    locations = [
        "ADIVA Desa ParkCity", "Alam Damai", "Ampang", "Ampang Hilir", "Bandar Damai Perdana",
        "Bandar Menjalara", "Bandar Sri Damansara", "Bandar Tasik Selatan", "Bangsar", "Bangsar South",
        "Batu Caves", "Brickfields", "Bukit Bintang", "Bukit Damansara", "Bukit Jalil", "Bukit Kiara",
        "Bukit Ledang", "Bukit Tunku (Kenny Hills)", "Chan Sow Lin", "Cheras", "City Centre",
        "Country Heights Damansara", "Damansara", "Damansara Heights", "Desa Pandan", "Desa ParkCity",
        "Desa Petaling", "Dutamas", "Federal Hill", "Gombak", "Gurney", "Jalan Ipoh", "Jalan Klang Lama (Old Klang Road)",
        "Jalan Kuching", "Jalan Sultan Ismail", "Jalan U-Thant", "Jinjang", "KL City", "KL Eco City",
        "KL Sentral", "KLCC", "Kemensah", "Kepong", "Keramat", "Klcc", "Kota Damansara", "Kuchai Lama",
        "Landed Sd", "Mid Valley City", "Mont Kiara", "OUG", "Other", "Pandan Indah", "Pandan Jaya",
        "Pandan Perdana", "Pantai", "Petaling Jaya", "Puchong", "Rawang", "SANTUARI PARK PANTAI",
        "SEMARAK", "Salak Selatan", "Segambut", "Sentul", "Seputeh", "Seri Kembangan", "Setapak",
        "Setiawangsa", "Sri Damansara", "Sri Hartamas", "Sri Petaling", "Sungai Besi", "Sungai Long SL8",
        "Sungai Penchala", "Sunway SPK", "Taman Desa", "Taman Duta", "Taman Ibukota", "Taman Melawati",
        "Taman Sri Keramat", "Taman TAR", "Taman Tun Dr Ismail", "Taman Wangsa Permai", "Taman Yarl",
        "Taman Yarl OUG", "Titiwangsa", "Ukay Heights", "Wangsa Maju", "duta Nusantara", "kepong",
        "taman cheras perdana"
    ]

    property_type = [
        "1-sty Terrace/Link House", "1-sty Terrace/Link House (Corner)", "1-sty Terrace/Link House (EndLot)",
        "1-sty Terrace/Link House (Intermediate)", "1.5-sty Terrace/Link House", "1.5-sty Terrace/Link House (Corner)",
        "1.5-sty Terrace/Link House (EndLot)", "1.5-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House",
        "2-sty Terrace/Link House (Corner)", "2-sty Terrace/Link House (Duplex)", "2-sty Terrace/Link House (EndLot)",
        "2-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House (Penthouse)", "2.5-sty Terrace/Link House",
        "2.5-sty Terrace/Link House (Corner)", "2.5-sty Terrace/Link House (EndLot)", "2.5-sty Terrace/Link House (Intermediate)",
        "2.5-sty Terrace/Link House (Triplex)", "3-sty Terrace/Link House", "3-sty Terrace/Link House (Corner)",
        "3-sty Terrace/Link House (Duplex)", "3-sty Terrace/Link House (EndLot)", "3-sty Terrace/Link House (Intermediate)",
        "3-sty Terrace/Link House (Triplex)", "3.5-sty Terrace/Link House", "3.5-sty Terrace/Link House (Corner)",
        "3.5-sty Terrace/Link House (EndLot)", "3.5-sty Terrace/Link House (Intermediate)", "4-sty Terrace/Link House",
        "4-sty Terrace/Link House (Corner)", "4-sty Terrace/Link House (Intermediate)", "4-sty Terrace/Link House (Penthouse)",
        "4.5-sty Terrace/Link House", "4.5-sty Terrace/Link House (Corner)", "4.5-sty Terrace/Link House (Intermediate)",
        "Apartment", "Apartment (Corner)", "Apartment (Duplex)", "Apartment (EndLot)", "Apartment (Intermediate)",
        "Apartment (Penthouse)", "Apartment Duplex", "Bungalow", "Bungalow Land", "Cluster House",
        "Condominium", "Condominium (Corner)", "Condominium (Duplex)", "Condominium (EndLot)", "Condominium (Intermediate)",
        "Condominium (Penthouse)", "Condominium Duplex", "Detached Factory/Warehouse", "Detached Office", "Detached Shop",
        "Duplex House", "Industrial Land", "Land (Residential)", "Link Bungalow", "Office", "Penthouse",
        "Retail Lot", "Semi-D Factory/Warehouse", "Semi-D House", "Semi-D Land", "Semi-Detached Office",
        "Semi-Detached Shop", "Service Apartment", "Service Apartment (Corner)", "Service Apartment (Duplex)",
        "Service Apartment (EndLot)", "Service Apartment (Intermediate)", "Service Apartment (Penthouse)", "Service Apartment Duplex",
        "Shop", "Shop Apartment", "Shop Office", "Soho", "Studio", "Superlink House", "Terrace Factory/Warehouse",
        "Town House", "Twin House", "Vacant/Empty Land", "Walk-up Apartment"
    ]

    # Input fields container
    with st.container():
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown('<div class="bold-label">Location</div>', unsafe_allow_html=True)
            Location = st.selectbox("", locations)
        with col2:
            st.markdown('<div class="bold-label">Number of Rooms</div>', unsafe_allow_html=True)
            NumberOfRooms = st.number_input("", min_value=0, step=1, key="num_rooms")
        with col3:
            st.markdown('<div class="bold-label">Number of Bathrooms</div>', unsafe_allow_html=True)
            NumberOfBathroom = st.number_input("", min_value=0, step=1, key="num_bathrooms")
        with col1:
            st.markdown('<div class="bold-label">Number of Car Parks</div>', unsafe_allow_html=True)
            NumberOfCarParks = st.number_input("", min_value=0, step=1, key="num_carparks")
        with col2:
            st.markdown('<div class="bold-label">Property Type</div>', unsafe_allow_html=True)
            PropertyType = st.selectbox("", property_type)
        with col3:
            st.markdown('<div class="bold-label">Furnishing</div>', unsafe_allow_html=True)
            Furnishing = st.selectbox("", ['Fully Furnished', 'Partially Furnished', 'Unfurnished'])
        with col1:
            st.markdown('<div class="bold-label">Size Type</div>', unsafe_allow_html=True)
            SizeType = st.selectbox("", ['Built-up', 'Land Area'])
        with col2:
            st.markdown('<div class="bold-label">Size Value (sq ft)</div>', unsafe_allow_html=True)
            SizeValue = st.number_input("", key="size_value")
        st.markdown('</div>', unsafe_allow_html=True)

    # Prediction
    price = ''
    if st.button('Predict House Price'):
        input_data = (
            locations.index(Location), NumberOfRooms, NumberOfBathroom, NumberOfCarParks,
            property_type.index(PropertyType), ['Fully Furnished', 'Partially Furnished', 'Unfurnished'].index(Furnishing), ['Built-up', 'Land Area'].index(SizeType), SizeValue
        )
        price = house_price_prediction(input_data)
        if price is not None:
            st.markdown(f'<div class="predicted-price">The Predicted Price: RM {price:,.2f}</div>', unsafe_allow_html=True)
        else:
            st.error('Prediction could not be made due to an error.')

    st.markdown("</div>", unsafe_allow_html=True)

if __name__ == '__main__':
    main()